from accounts.models import User
from django.shortcuts import render, HttpResponse


def get_charity_members(request):
    users = User.objects.all()
    user_names = [user.get_full_name() for user in users]
    context = {
        'user_names': user_names
    }
    return HttpResponse(user_names)